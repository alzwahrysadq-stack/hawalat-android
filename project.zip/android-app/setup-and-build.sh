#!/bin/bash
set -e
echo ""
echo "======================================================"
echo "  مستخرج الحوالات — إعداد وبناء تلقائي"
echo "======================================================"
echo ""

# 1) فحص Node.js
if ! command -v node &> /dev/null; then
  echo "❌ Node.js غير مثبت. حمّله من https://nodejs.org (الإصدار 18 أو أحدث)"
  exit 1
fi
echo "✅ Node.js: $(node --version)"

# 2) فحص Java
if ! command -v java &> /dev/null; then
  echo "❌ Java غير موجود. حمّل JDK 17 من https://adoptium.net"
  exit 1
fi
echo "✅ Java: $(java -version 2>&1 | head -1)"

# 3) فحص Android SDK
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
  echo "⚠️  متغير ANDROID_HOME غير مضبوط."
  echo "   إذا كنت ستفتح المشروع عبر Android Studio، يمكنك تجاهل هذا التحذير."
fi

# 4) تثبيت التبعيات
echo ""
echo "📦 تثبيت التبعيات (npm install)..."
npm install

# 5) مزامنة Capacitor
echo ""
echo "🔄 مزامنة Capacitor (npx cap sync android)..."
npx cap sync android

# 6) اختياري: بناء Debug APK تلقائياً
echo ""
echo "🔨 محاولة بناء APK للتطوير (Debug)..."
cd android
if [ -f "./gradlew" ]; then
  chmod +x gradlew
  ./gradlew assembleDebug
  echo ""
  echo "============================================================"
  echo "✅ تم البناء! الملف في: android/app/build/outputs/apk/debug/"
  echo "   اسمه: app-debug.apk"
  echo "============================================================"
else
  echo "⚠️  لم يُعثر على gradlew. افتح المشروع في Android Studio:"
  echo "   File → Open → اختر مجلد android داخل هذا المشروع"
  echo "   ثم اضغط Run (▶) مباشرة"
fi
