@echo off
chcp 65001 > nul
echo.
echo ======================================================
echo   مستخرج الحوالات — إعداد وبناء تلقائي (Windows)
echo ======================================================
echo.

node --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo [خطأ] Node.js غير مثبت. حمّله من https://nodejs.org
    pause & exit /b 1
)
echo [تم] Node.js موجود

java -version >nul 2>&1
IF ERRORLEVEL 1 (
    echo [خطأ] Java غير موجود. حمّل JDK 17 من https://adoptium.net
    pause & exit /b 1
)
echo [تم] Java موجود

echo.
echo [1/3] تثبيت التبعيات...
call npm install
IF ERRORLEVEL 1 ( echo [خطأ] npm install فشل & pause & exit /b 1 )

echo.
echo [2/3] مزامنة Capacitor...
call npx cap sync android
IF ERRORLEVEL 1 ( echo [خطأ] cap sync فشل & pause & exit /b 1 )

echo.
echo [3/3] بناء APK...
cd android
IF EXIST gradlew.bat (
    call gradlew.bat assembleDebug
    IF ERRORLEVEL 1 (
        echo [تحذير] فشل البناء التلقائي.
        echo افتح مجلد 'android' في Android Studio ثم اضغط Run.
    ) ELSE (
        echo.
        echo ========================================================
        echo [تم] APK جاهز في: android\app\build\outputs\apk\debug\
        echo ========================================================
    )
) ELSE (
    echo لم يُعثر على gradlew.bat
    echo افتح Android Studio واختر: File - Open - مجلد android
    echo ثم اضغط Run
)
cd ..
echo.
pause
