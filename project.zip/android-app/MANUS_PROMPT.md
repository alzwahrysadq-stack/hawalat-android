# Manus Prompt — Build Android APK for "مستخرج الحوالات"

## Context (Read carefully before doing anything)

I have a complete, production-ready Android app project inside a ZIP file.
The app is called **"مستخرج الحوالات"** (Hawala Extractor).

### ⚠️ Critical rule — DO NOT touch this file:
`www/index.html` — This is an 88,000+ line single-file HTML/JS app.
**Do not read it, do not modify it, do not rewrite it, do not summarize it.**
Treat it as a black box. Your only job is to compile it into an APK.

---

## Your Task

Build a release-ready **Android APK** from the existing Capacitor project.

---

## Project Structure (already in the ZIP)

```
android-app/
├── www/
│   ├── index.html          ← MAIN APP — DO NOT TOUCH
│   ├── manifest.json
│   ├── sw.js
│   └── *.png               ← icons
├── android/
│   ├── app/
│   │   ├── build.gradle    ← applicationId: com.aldhahri.hawalat
│   │   ├── proguard-rules.pro
│   │   └── src/main/
│   │       ├── AndroidManifest.xml
│   │       ├── java/com/aldhahri/hawalat/MainActivity.java
│   │       └── res/        ← icons, strings, styles, xml
│   ├── build.gradle
│   ├── settings.gradle
│   ├── variables.gradle
│   ├── gradle.properties
│   ├── gradlew
│   └── gradle/wrapper/gradle-wrapper.properties
├── capacitor.config.json
└── package.json
```

---

## Exact Steps to Execute

### Step 1 — Install dependencies
```bash
cd android-app
npm install
```

### Step 2 — Sync Capacitor
```bash
npx cap sync android
```

### Step 3 — Set up Android SDK (if not already installed)
Install Android SDK with:
- Build Tools: 34.x
- Platform: Android 34
- Java JDK: 17

### Step 4 — Build Debug APK (fast, for testing)
```bash
cd android
chmod +x gradlew
./gradlew assembleDebug
```
Output: `android/app/build/outputs/apk/debug/app-debug.apk`

### Step 5 — (Optional) Build Release APK
Only if you have a keystore. Otherwise debug APK is sufficient.

```bash
# Create keystore (run once):
keytool -genkey -v \
  -keystore hawalat.jks \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias hawalat \
  -dname "CN=Sadeq AlDhahri, OU=Hawalat, O=AlDhahri, L=Sanaa, ST=Yemen, C=YE"

# Create android/keystore.properties:
echo "storeFile=../hawalat.jks
storePassword=YOUR_PASSWORD
keyAlias=hawalat
keyPassword=YOUR_PASSWORD" > android/keystore.properties

# Build release:
./gradlew assembleRelease
```
Output: `android/app/build/outputs/apk/release/app-release.apk`

---

## What SUCCESS looks like

- ✅ `npm install` completes without errors
- ✅ `npx cap sync android` copies `www/` into `android/app/src/main/assets/public/`
- ✅ `./gradlew assembleDebug` exits with `BUILD SUCCESSFUL`
- ✅ APK file exists at the output path above

---

## If you encounter errors

| Error | Fix |
|---|---|
| `SDK location not found` | Set `sdk.dir` in `android/local.properties` |
| `JAVA_HOME not set` | Install JDK 17, set JAVA_HOME |
| `gradlew: Permission denied` | Run `chmod +x android/gradlew` |
| `Gradle wrapper jar not found` | Run `gradle wrapper --gradle-version=8.7` inside `android/` |
| `capacitor-android not found` | Ensure `npm install` completed successfully |
| `compileSdkVersion 34 not found` | Install Android SDK Platform 34 via sdkmanager |

---

## Absolute constraints

1. **NEVER modify `www/index.html`** — not a single character
2. **NEVER rewrite the app** from scratch
3. **NEVER change** `applicationId`, `versionCode`, or package name
4. **NEVER add** new features, screens, or business logic
5. **DO NOT** use Cordova, React Native, Flutter, or any other framework
6. **DO NOT** install unnecessary packages beyond what's in `package.json`
7. If something fails, fix the **build config only** — never touch `www/`

---

## Expected output

Please provide:
1. The **APK file** (`app-debug.apk` or `app-release.apk`)
2. A brief log of the build commands you ran
3. APK file size and SHA256 checksum

App details:
- Name: مستخرج الحوالات
- Package: com.aldhahri.hawalat
- Version: 1.0.0 (versionCode 1)
- Min Android: 7.0 (API 24)
- Target Android: 14 (API 34)

