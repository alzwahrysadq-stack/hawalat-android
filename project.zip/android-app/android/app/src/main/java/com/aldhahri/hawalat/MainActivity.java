package com.aldhahri.hawalat;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

/**
 * النشاط الرئيسي للتطبيق.
 *
 * ملاحظة حول زر الرجوع: جسر Capacitor (BridgeActivity) يتعامل افتراضيًا مع زر
 * الرجوع بالشكل الصحيح:
 *   1) إن كان هناك تاريخ تصفح داخل WebView (مثلاً بعد فتح جدول أو نافذة داخلية) يرجع خطوة داخل الصفحة.
 *   2) إن لم يوجد تاريخ، يُغلق التطبيق (أو حسب استماع JS لحدث backButton إن أردت تأكيد الخروج).
 *
 * لإضافة تأكيد "اضغط مرة أخرى للخروج" بدل الإغلاق الفوري، يمكن الاستماع من صفحة الويب نفسها إلى:
 *   window.addEventListener('backbutton', ...)  (بعد تفعيل @capacitor/app)
 * دون أي تعديل هنا في الكود الأصلي داخل index.html.
 */
public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
