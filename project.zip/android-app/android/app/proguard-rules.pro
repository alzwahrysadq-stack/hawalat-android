# حافظ على جسر Capacitor وواجهات JavaScript كي لا يكسر التصغير Build الإنتاج
-keep public class com.getcapacitor.** { *; }
-keep public class com.aldhahri.hawalat.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
-keepattributes *Annotation*

# مكتبات PDF/Excel داخل صفحة الويب نفسها لا تتأثر بـ ProGuard لأنها JS خالص
# لا حاجة لقواعد إضافية طالما لا تُستخدم مكتبات Java/Kotlin خارجية للمعالجة.
